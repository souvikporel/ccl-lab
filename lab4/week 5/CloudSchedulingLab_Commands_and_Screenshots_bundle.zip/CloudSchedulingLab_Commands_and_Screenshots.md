# Cloud Scheduling Lab --- Commands and Screenshot Notes

This document combines the terminal and code screenshots shared in the
conversation, along with the commands visible in them.

## 1. Resolve Maven dependencies

**Command**

``` bash
mvn dependency:resolve
```

**What the screenshot shows**

Maven starts scanning the project but cannot parse `pom.xml`. The
reported location is **line 3, column 11**, with the message
`expected = after attribute name`. The screenshot does not show a
successful dependency-resolution run.

![Maven dependency resolution
error](images/01-maven-dependency-resolve-error.png)

## 2. Open the Java scheduling experiment

**Command shown in the terminal title**

``` bash
nano src/main/java/lab/SchedulingExperiment.java
```

**What the screenshots show**

The Java source file `SchedulingExperiment.java` defines scheduling
constants and invokes four combinations:

-   VM SpaceShared + Cloudlet SpaceShared
-   VM SpaceShared + Cloudlet TimeShared
-   VM TimeShared + Cloudlet SpaceShared
-   VM TimeShared + Cloudlet TimeShared

The screenshots show the beginning of the `runScenario(...)` method;
they do not show the complete method body.

![Scheduling experiment source
code](images/02-scheduling-experiment-code.png)

![Scheduling experiment source code --- second
capture](images/03-scheduling-experiment-code-duplicate.png)

## 3. Run the scheduling experiment with Maven

**Command visible in the terminal**

``` bash
mvn exec:java -Dexec.mainClass=lab.SchedulingExperiment -Dexec.classpathScope=compile
```

**What the screenshot shows**

The Maven exec plugin starts CloudSim Plus 7.3.0. The output shows the
first scenario, `VM SpaceShared + Cloudlet SpaceShared`, starting;
datacenter and broker startup messages appear, two VMs are allocated,
and cloudlets are sent to the VMs.

![CloudSim execution output](images/04-cloudsim-execution-output.png)

## 4. Run using the fully qualified exec-maven-plugin goal

**Command visible in the terminal**

``` bash
mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java -Dexec.mainClass="lab.SchedulingExperiment" -Dexec.classpathScope=compile
```

**What the screenshot shows**

Maven downloads the `exec-maven-plugin` 3.5.0 and related dependencies
from Maven Central, then begins building
`cloud-scheduling-lab 1.0-SNAPSHOT`. The captured output shows
dependency downloads and the build startup; it does not show the final
experiment results.

![Maven plugin download and build
output](images/05-maven-plugin-download-output.png)

## Command checklist

Run these from the project root (`~/CloudSchedulingLab`):

``` bash
# Open the Java experiment source
nano src/main/java/lab/SchedulingExperiment.java

# Resolve project dependencies
mvn dependency:resolve

# Run using the configured exec plugin
mvn exec:java -Dexec.mainClass=lab.SchedulingExperiment -Dexec.classpathScope=compile

# Run by specifying the exec-maven-plugin version explicitly
mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java -Dexec.mainClass="lab.SchedulingExperiment" -Dexec.classpathScope=compile
```

**Note:** The screenshots document the commands and visible output only.
They do not establish that every command completed successfully. In
particular, the dependency-resolution screenshot records a `pom.xml`
parsing error.
